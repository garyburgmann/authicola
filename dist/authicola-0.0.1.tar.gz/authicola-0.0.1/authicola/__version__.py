"""Metadata for Authicola package."""
__title__ = 'authicola'
__description__ = 'A convenience libary of OAuth2.0 providers'
__url__ = 'https://github.com/garyburgmann/authicola'
__version__ = '0.0.1'
__author__ = 'Gary Burgmann'
__author_email__ = 'garyburgmann@gmail.com'
__license__ = 'MIT'
