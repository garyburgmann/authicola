DRIVER_CONFIG = {
    'google': {
        'access_token_url': 'https://www.googleapis.com/oauth2/v4/token',
        'authorization_url': 'https://accounts.google.com/o/oauth2/v2/auth',
        'profile_url': 'https://www.googleapis.com/oauth2/v2/userinfo'
    }
}
